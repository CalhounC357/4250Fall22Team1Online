﻿
All the HTML is under the Views folder
CSS, Images, and Javascript is in the wwwroot folder

To view the database tables download Db Browser (https://sqlitebrowser.org/) and open the ScavengeRUS.db