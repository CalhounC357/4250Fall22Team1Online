﻿namespace ScavengeRUs.Models.Enums
{
         public enum Roles { Player, Admin };
}
